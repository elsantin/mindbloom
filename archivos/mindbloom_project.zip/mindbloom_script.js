
        document.addEventListener('DOMContentLoaded', () => {
            // Hide loading screen after page loads
            const loadingOverlay = document.getElementById('loading-overlay');
            setTimeout(() => {
                loadingOverlay.classList.add('fade-out');
                setTimeout(() => {
                    loadingOverlay.style.display = 'none';
                }, 500);
            }, 1000);

            // Theme Management with improved performance
            const themeToggle = document.getElementById('theme-toggle');
            const savedTheme = localStorage.getItem('theme') || 'dark';
            
            // Set initial theme
            if (savedTheme === 'light') {
                document.documentElement.setAttribute('data-theme', 'light');
            }

            themeToggle.addEventListener('click', () => {
                const currentTheme = document.documentElement.getAttribute('data-theme');
                const newTheme = currentTheme === 'light' ? 'dark' : 'light';
                
                document.documentElement.setAttribute('data-theme', newTheme);
                localStorage.setItem('theme', newTheme);
                
                showToast(newTheme === 'light' ? '☀️ Modo claro activado' : '🌙 Modo oscuro activado');
            });

            // Mobile Menu Toggle with improved accessibility
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const body = document.body;
            const navLinks = document.getElementById('nav-links');

            mobileMenuButton.addEventListener('click', () => {
                const isOpen = body.classList.contains('nav-open');
                body.classList.toggle('nav-open');
                
                // Update ARIA attributes
                mobileMenuButton.setAttribute('aria-expanded', !isOpen);
                navLinks.setAttribute('aria-hidden', isOpen);
            });

            // Close mobile menu when clicking on a link
            const mobileLinks = document.querySelectorAll('#nav-links a');
            mobileLinks.forEach(link => {
                link.addEventListener('click', () => {
                    body.classList.remove('nav-open');
                    mobileMenuButton.setAttribute('aria-expanded', 'false');
                    navLinks.setAttribute('aria-hidden', 'true');
                });
            });

            // Close mobile menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!e.target.closest('#mobile-menu-button') && !e.target.closest('#nav-links')) {
                    body.classList.remove('nav-open');
                    mobileMenuButton.setAttribute('aria-expanded', 'false');
                    navLinks.setAttribute('aria-hidden', 'true');
                }
            });

            // Enhanced Scroll Animation using Intersection Observer
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -10% 0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animate');
                        // Stop observing after animation to improve performance
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);

            // Observe all sections with animation class
            const animateElements = document.querySelectorAll('.section-animation');
            animateElements.forEach(el => observer.observe(el));

            // Enhanced Emoji Check-in Interaction
            const emojiButtons = document.querySelectorAll('.emoji-btn');
            emojiButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                    // Remove selected class from all buttons
                    emojiButtons.forEach(b => b.classList.remove('selected'));
                    // Add selected class to clicked button
                    btn.classList.add('selected');
                    
                    const feeling = btn.dataset.feeling;
                    const feelingMap = {
                        feliz: 'Me alegra saber que te sientes bien hoy 😊',
                        triste: 'Es normal sentirse así a veces. Estamos aquí para ti 💚',
                        ansioso: 'La ansiedad es difícil, pero juntos podemos manejarla 🌱',
                        enojado: 'Tus sentimientos son válidos. Hablemos de ello 🤝',
                        confundido: 'Está bien no tener todas las respuestas. Te acompañamos 💭'
                    };
                    
                    showToast(feelingMap[feeling] || 'Gracias por compartir cómo te sientes 💚');
                });
            });

            // Enhanced toast notification function
            function showToast(message, duration = 4000) {
                // Remove existing toasts
                const existingToasts = document.querySelectorAll('.toast-notification');
                existingToasts.forEach(toast => toast.remove());

                const toast = document.createElement('div');
                toast.className = 'toast-notification fixed bottom-4 left-4 bg-accent text-white px-6 py-3 rounded-lg shadow-lg z-50 transform translate-y-full transition-all duration-300 max-w-sm';
                toast.style.color = document.documentElement.getAttribute('data-theme') === 'light' ? '#FFFFFF' : '#1A1A1A';
                toast.textContent = message;
                document.body.appendChild(toast);
                
                setTimeout(() => {
                    toast.style.transform = 'translateY(0)';
                }, 100);
                
                setTimeout(() => {
                    toast.style.transform = 'translateY(100%)';
                    setTimeout(() => {
                        if (document.body.contains(toast)) {
                            document.body.removeChild(toast);
                        }
                    }, 300);
                }, duration);
            }

            // Enhanced smooth scrolling for navigation links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const targetId = this.getAttribute('href');
                    const target = document.querySelector(targetId);
                    if (target) {
                        const headerHeight = document.querySelector('header').offsetHeight;
                        const targetPosition = target.offsetTop - headerHeight - 20;
                        
                        window.scrollTo({
                            top: targetPosition,
                            behavior: 'smooth'
                        });
                    }
                });
            });

            // Emergency button with enhanced accessibility
            const emergencyButton = document.getElementById('emergency-button');
            emergencyButton.addEventListener('click', () => {
                if (confirm('¿Estás en una situación de emergencia? Te conectaremos con ayuda inmediata.')) {
                    showToast('Conectando con línea de crisis... 🚨');
                    // Here you would integrate with actual emergency services
                    setTimeout(() => {
                        window.open('tel:171', '_self');
                    }, 1000);
                }
            });

            // Add keyboard navigation support
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    body.classList.remove('nav-open');
                    mobileMenuButton.setAttribute('aria-expanded', 'false');
                    navLinks.setAttribute('aria-hidden', 'true');
                }
            });

            // Improved performance monitoring
            if ('PerformanceObserver' in window) {
                const observer = new PerformanceObserver((list) => {
                    for (const entry of list.getEntries()) {
                        if (entry.entryType === 'navigation') {
                            console.log('Page load time:', entry.loadEventEnd - entry.loadEventStart);
                        }
                    }
                });
                observer.observe({entryTypes: ['navigation']});
            }

            // Add focus management for better accessibility
            const focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
            const modal = document.querySelector('#nav-links');
            
            function trapFocus(element) {
                const focusables = element.querySelectorAll(focusableElements);
                const firstFocusable = focusables[0];
                const lastFocusable = focusables[focusables.length - 1];

                element.addEventListener('keydown', (e) => {
                    if (e.key === 'Tab') {
                        if (e.shiftKey) {
                            if (document.activeElement === firstFocusable) {
                                lastFocusable.focus();
                                e.preventDefault();
                            }
                        } else {
                            if (document.activeElement === lastFocusable) {
                                firstFocusable.focus();
                                e.preventDefault();
                            }
                        }
                    }
                });
            }

            // Initialize focus trap for mobile menu
            if (modal) {
                trapFocus(modal);
            }
        });
    


        window.__genspark_remove_badge_link = "https://www.genspark.ai/api/html_badge/" +
            "remove_badge?token=To%2FBnjzloZ3UfQdcSaYfDoGyhf7r0%2FTUH4PN45MEntlT5wwA06Xteeek1L4hMes7vlJAhvMJIkZSO6G0lV6PMM1PYlLkz%2BoRVExSFDcgAn4cz8tpUyoZgKS0ubvcnXRsV5HyWVh6b6ZlP73kafOYKv4Y4BLehPc7Lb9SjyJm%2BWjAsYmliEyLw0i0VaQpGJOGdIr5WHSSGj2qQA9U2r356Y3OIadLDD0I8niEOdmWH8QV5Yvw8WO0vlWSTWppt12rpsfj2R%2BAaECEd%2BKOYgHFIXknRb9Xr9rs3djM5AtI5urL0Xu78iSHAlHpBtjc4chLXujZYae%2FAqrVDLtUMP2aEEO2jiGCUX7oCzGufn%2B%2FJhLzCGFHfxS9j15eWKFTQCKNtoMPMdPwuGLeWC2uslxBb9kN756D1nVMGwW%2FFnPk3fe3s7DDbrBZPOCBW2lGU4bXbtT6p43HN0Ej4wfykGdbKWJ7GG7YXmEBzJxlpnAE29aGEQQOa9kRcn6KhSzMiP%2F8JPwTaw%2FAiCgF5lUoetkm7g%3D%3D";
        window.__genspark_locale = "en-US";
        window.__genspark_token = "To/BnjzloZ3UfQdcSaYfDoGyhf7r0/TUH4PN45MEntlT5wwA06Xteeek1L4hMes7vlJAhvMJIkZSO6G0lV6PMM1PYlLkz+oRVExSFDcgAn4cz8tpUyoZgKS0ubvcnXRsV5HyWVh6b6ZlP73kafOYKv4Y4BLehPc7Lb9SjyJm+WjAsYmliEyLw0i0VaQpGJOGdIr5WHSSGj2qQA9U2r356Y3OIadLDD0I8niEOdmWH8QV5Yvw8WO0vlWSTWppt12rpsfj2R+AaECEd+KOYgHFIXknRb9Xr9rs3djM5AtI5urL0Xu78iSHAlHpBtjc4chLXujZYae/AqrVDLtUMP2aEEO2jiGCUX7oCzGufn+/JhLzCGFHfxS9j15eWKFTQCKNtoMPMdPwuGLeWC2uslxBb9kN756D1nVMGwW/FnPk3fe3s7DDbrBZPOCBW2lGU4bXbtT6p43HN0Ej4wfykGdbKWJ7GG7YXmEBzJxlpnAE29aGEQQOa9kRcn6KhSzMiP/8JPwTaw/AiCgF5lUoetkm7g==";
    